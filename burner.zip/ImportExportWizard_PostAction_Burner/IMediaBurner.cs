﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IMediaBurner.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner
{
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using System.Runtime.InteropServices.ComTypes;

    using ImportExportWizard_PostAction_Burner.Interop;
    using ImportExportWizard_PostAction_Burner.MediaItem;

    /// <summary>
    /// Definition of a media burner providing support for CD, DVD and BluRay format, ISO
    /// generation and burning support.
    /// </summary>
    public interface IMediaBurner
    {
        /// <summary>
        /// Gets a list of recorder information.
        /// </summary>
        IList<KeyValuePair<MsftDiscRecorder2, string>> RecordersInfo { get; }

        /// <summary>
        /// Gets whether the media can be written to.
        /// </summary>
        /// <param name="rec">
        /// The recorder containing the media in question.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/> result indicating true if it can be written to; false otherwise.
        /// </returns>
        bool CanWriteMedia(MsftDiscRecorder2 rec);

        /// <summary>
        /// Create a <see cref="IStream"/> for the array of <see cref="IMediaItem"/> objects.
        /// </summary>
        /// <param name="discRecorder">
        /// The <see cref="IDiscRecorder2"/> to target creation for.
        /// </param>
        /// <param name="volumeName">
        /// Name of the label to give the stream.
        /// </param>
        /// <param name="mediaItems">
        /// The media items to create the image from.
        /// </param>
        /// <param name="multisessionInterfaces">
        /// Any multi session interfaces to take into consideration.
        /// </param>
        /// <param name="fileSystemFormat">
        /// The file system format that will be created.
        /// </param>
        /// <param name="dataStream">
        /// The resulting <see cref="IStream"/>.
        /// </param>
        /// <returns>
        /// Returns a <see cref="bool"/> indicating success when true; false otherwise.
        /// </returns>
        bool CreateMediaFileSystem(
            IDiscRecorder2 discRecorder,
            string volumeName,
            IMediaItem[] mediaItems,
            object[] multisessionInterfaces,
            FsiFileSystems fileSystemFormat,
            out IStream dataStream);

        /// <summary>
        /// Gets the current physical media type for the given recorder.
        /// </summary>
        /// <param name="rec">
        /// The recorder in question.
        /// </param>
        /// <returns>
        /// Returns the <see cref="IMAPI_MEDIA_PHYSICAL_TYPE"/>.
        /// </returns>
        IMAPI_MEDIA_PHYSICAL_TYPE CurrentPhysicalMediaType(MsftDiscRecorder2 rec);

        /// <summary>
        /// Format the media contained within the recorder specified by the unique descriptor.
        /// </summary>
        /// <param name="recorderDescriptor">
        /// The disc recorder unique descriptor.
        /// </param>
        /// <param name="clientName">
        /// The client name requiring exclusive access to the recorder (IMAPI2 usually).
        /// </param>
        /// <param name="quick">
        /// Whether a quick format should be done.
        /// </param>
        /// <param name="eject">
        /// Whether the media should be ejected after the process completes.
        /// </param>
        /// <returns>
        /// Returns the exit code where 0 indicates success; otherwise fail.
        /// </returns>
        int FormatMedia(string recorderDescriptor, string clientName, bool quick, bool eject);

        /// <summary>
        /// Gets the media state description for the given recorder.
        /// </summary>
        /// <param name="rec">
        /// The recorder in question.
        /// </param>
        /// <returns>
        /// The <see cref="string"/> description.
        /// </returns>
        string GetMediaStateDescription(MsftDiscRecorder2 rec);

        /// <summary>
        /// Gets a list of general media types supported by recorders.
        /// </summary>
        /// <returns>
        /// The list of physical media type keypair descriptions.
        /// </returns>
        IList<KeyValuePair<IMAPI_MEDIA_PHYSICAL_TYPE, string>> GetMediaTypes();

        /// <summary>
        /// Gets a list of write speed descriptors for the specified recorder.
        /// </summary>
        /// <param name="rec">
        /// The recorder in question.
        /// </param>
        /// <returns>
        /// The list of write speed descriptor keypairs.
        /// </returns>
        IList<KeyValuePair<IWriteSpeedDescriptor, string>> GetSpeedDescriptors(MsftDiscRecorder2 rec);

        /// <summary>
        /// Gets whether the media is blank in the specified recorder.
        /// </summary>
        /// <param name="rec">
        /// The recorder in question.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/> result indicating true if blank; false otherwise.
        /// </returns>
        bool IsMediaBlank(MsftDiscRecorder2 rec);

        /// <summary>
        /// Gets the supported media types for the specified recorder.
        /// </summary>
        /// <param name="rec">
        /// The recorder in question.
        /// </param>
        /// <returns>
        /// Returns the <see cref="List{IMAPI_MEDIA_PHYSICAL_TYPE}"/>.
        /// </returns>
        List<IMAPI_MEDIA_PHYSICAL_TYPE> SupportedMediaTypes(MsftDiscRecorder2 rec);

        /// <summary>
        /// Update called when the status/progress of a disc format changes.
        /// </summary>
        /// <param name="sender">
        /// Sender of the update.
        /// </param>
        /// <param name="prog">
        /// The progress data.
        /// </param>
        void UpdateDiscFormatData(
            [In, MarshalAs(UnmanagedType.IDispatch)]
            object sender,
            [In, MarshalAs(UnmanagedType.IDispatch)]
            object prog);

        /// <summary>
        /// Update called when the status/progress of a disc erase changes.
        /// </summary>
        /// <param name="sender">
        /// Sender of the update.
        /// </param>
        /// <param name="elapsedSeconds">
        /// Seconds elapsed.
        /// </param>
        /// <param name="estimatedTotalSeconds">
        /// Estimated total seconds until complete.
        /// </param>
        void UpdateDiscFormatEraseData(
            [In, MarshalAs(UnmanagedType.IDispatch)]
            object sender,
            int elapsedSeconds,
            int estimatedTotalSeconds);

        /// <summary>
        /// Handle an update event raised from the <see cref="IFileSystemImage"/> instance.
        /// </summary>
        /// <param name="sender">
        /// Sender of the event.
        /// </param>
        /// <param name="currentFile">
        /// The file being processed.
        /// </param>
        /// <param name="copiedSectors">
        /// Total sectors copied.
        /// </param>
        /// <param name="totalSectors">
        /// Total sectors to copy.
        /// </param>
        void UpdateFileSystemImage(
            [In, MarshalAs(UnmanagedType.IDispatch)]
            object sender,
            [In, MarshalAs(UnmanagedType.BStr)] string currentFile,
            [In] int copiedSectors,
            [In] int totalSectors);

        /// <summary>
        /// Write the provided array of <see cref="IMediaItem"/> items using the specified recorder.
        /// </summary>
        /// <param name="clientName">
        /// Client name that will obtain an exclusive lock on the recorder while recording.
        /// </param>
        /// <param name="recorderDescriptor">
        /// The recorder descriptor to use to burn the media.
        /// </param>
        /// <param name="volumeLabel">
        /// The volume label for the disc.
        /// </param>
        /// <param name="content">
        /// The media content to write.
        /// </param>
        /// <param name="forceClose">
        /// Should the disc be forcibly closed at the end of the burn process?
        /// </param>
        /// <param name="speed">
        /// The burn speed.
        /// </param>
        /// <param name="eject">
        /// Should the disc be ejected after the burn process has completed?
        /// </param>
        /// <param name="fileSystemFormat">
        /// The file system format for the created disc.
        /// </param>
        /// <returns>
        /// Return the exit code where 0 is success; failed otherwise.
        /// </returns>
        int WriteContent(
            string clientName,
            string recorderDescriptor,
            string volumeLabel,
            IMediaItem[] content,
            bool forceClose,
            int speed,
            bool eject,
            FsiFileSystems fileSystemFormat = FsiFileSystems.FsiFileSystemISO9660 | FsiFileSystems.FsiFileSystemJoliet);

        /// <summary>
        /// Write the specified stream to the media contained within the specified recorder.
        /// </summary>
        /// <param name="stream">
        /// The stream to write to the media.
        /// </param>
        /// <param name="recorderDescriptor">
        /// The disc recorder unique descriptor.
        /// </param>
        /// <param name="clientName">
        /// The client name requiring exclusive access to the recorder (IMAPI2 usually).
        /// </param>
        /// <param name="forceClose">
        /// Whether the media should be forced to close.
        /// </param>
        /// <param name="speed">
        /// The indicated speed at which the write should be performed at if possible.
        /// </param>
        /// <param name="eject">
        /// Whether the media should be ejected after the process completes.
        /// </param>
        /// <returns>
        /// The <see cref="int"/> status where 0 is success; otherwise an error occurred.
        /// </returns>
        int WriteStream(
            IStream stream,
            string recorderDescriptor,
            string clientName,
            bool forceClose,
            int speed,
            bool eject);
    }
}