﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IMediaItem.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.MediaItem
{
    using System.Drawing;

    using ImportExportWizard_PostAction_Burner.Interop;

    /// <summary>
    /// Represents a directory or file item and associated attributes.
    /// </summary>
    public interface IMediaItem
    {
        /// <summary>
        /// Gets the full path of the file or directory.
        /// </summary>
        string Path { get; }

        /// <summary>
        /// Gets the size of the file or directory to the next largest sector.
        /// </summary>
        long SizeOnDisc { get; }

        /// <summary>
        /// Gets the icon of the file or directory.
        /// </summary>
        Image FileIconImage { get; }

        /// <summary>
        /// Adds the file or directory to the root <see cref="IFsiDirectoryItem"/>.
        /// </summary>
        /// <param name="rootItem">
        /// The root <see cref="IFsiDirectoryItem"/>.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/> result where true is success; false otherwise.
        /// </returns>
        bool AddToFileSystem(IFsiDirectoryItem rootItem);
    }
}
