﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DirectoryItem.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.MediaItem
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;

    using ImportExportWizard_PostAction_Burner.Interop;

    /// <summary>
    /// Represents a directory item and any files/folders within.
    /// </summary>
    public sealed class DirectoryItem : IMediaItem
    {
        /// <summary>
        /// The display name.
        /// </summary>
        private readonly string displayName;

        /// <summary>
        /// The media items.
        /// </summary>
        private readonly List<IMediaItem> mediaItems = new List<IMediaItem>();

        /// <summary>
        /// Initializes a new instance of the <see cref="DirectoryItem"/> class. 
        /// </summary>
        /// <param name="directoryPath">
        /// The path to the directory.
        /// </param>
        public DirectoryItem(string directoryPath)
        {
            if (!Directory.Exists(directoryPath))
            {
                throw new FileNotFoundException("The directory added to DirectoryItem was not found!", directoryPath);
            }

            this.Path = directoryPath;
            var fileInfo = new FileInfo(this.Path);
            this.displayName = fileInfo.Name;

            var files = Directory.GetFiles(this.Path);
            foreach (var file in files)
            {
                this.mediaItems.Add(new FileItem(file));
            }

            var directories = Directory.GetDirectories(this.Path);
            foreach (var directory in directories)
            {
                this.mediaItems.Add(new DirectoryItem(directory));
            }

            var shinfo = new Shell32FileInfo();
            Win32.SHGetFileInfo(
                this.Path,
                0,
                ref shinfo,
                (uint)Marshal.SizeOf(shinfo),
                Win32.ShellGetFileInformationIcon | Win32.ShellGetFileInformationSmallIcon);

            var imageConverter = new IconConverter();
            var icon = Icon.FromHandle(shinfo.iconHandle);
            try
            {
                this.FileIconImage = (Image)imageConverter.ConvertTo(icon, typeof(Image));
            }
            catch (NotSupportedException)
            {
            }

            Win32.DestroyIcon(shinfo.iconHandle);
        }

        /// <summary>
        /// Gets the icon for this directory item.
        /// </summary>
        public Image FileIconImage { get; }

        /// <summary>
        /// Gets the path to the directory.
        /// </summary>
        public string Path { get; }

        /// <summary>
        /// Gets the size on disc.
        /// </summary>
        public long SizeOnDisc => this.mediaItems.Sum(x => x.SizeOnDisc);

        /// <summary>
        /// Adds the directory to the root <see cref="IFsiDirectoryItem"/>.
        /// </summary>
        /// <param name="rootItem">
        /// The root <see cref="IFsiDirectoryItem"/>.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/> result where true is success; false otherwise.
        /// </returns>
        public bool AddToFileSystem(IFsiDirectoryItem rootItem)
        {
            try
            {
                rootItem.AddTree(this.Path, true);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error adding folder", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// Converts this object to a string for display.
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        public override string ToString()
        {
            return this.displayName;
        }
    }
}