﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="FileItem.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.MediaItem
{
    using System;
    using System.Drawing;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Runtime.InteropServices.ComTypes;
    using System.Windows.Forms;

    using ImportExportWizard_PostAction_Burner.Interop;

    /// <summary>
    /// Represents a file item.
    /// </summary>
    public sealed class FileItem : IMediaItem
    {
        /// <summary>
        /// The default sector size.
        /// </summary>
        private const long SectorSize = 2048;

        /// <summary>
        /// The display name.
        /// </summary>
        private readonly string displayName;

        /// <summary>
        /// The length of the file.
        /// </summary>
        private readonly long fileLength;

        /// <summary>
        /// Initializes a new instance of the <see cref="FileItem"/> class.
        /// </summary>
        /// <param name="path">
        /// The path to the file.
        /// </param>
        /// <exception cref="FileNotFoundException">
        /// Thrown if the file could not be found.
        /// </exception>
        public FileItem(string path)
        {
            if (!File.Exists(path))
            {
                throw new FileNotFoundException("The file added to FileItem was not found!", path);
            }

            this.Path = path;
            var fileInfo = new FileInfo(this.Path);
            this.displayName = fileInfo.Name;
            this.fileLength = fileInfo.Length;

            var shinfo = new Shell32FileInfo();
            Win32.SHGetFileInfo(
                this.Path,
                0,
                ref shinfo,
                (uint)Marshal.SizeOf(shinfo),
                Win32.ShellGetFileInformationIcon | Win32.ShellGetFileInformationSmallIcon);

            var imageConverter = new IconConverter();
            var icon = Icon.FromHandle(shinfo.iconHandle);
            try
            {
                this.FileIconImage = (Image)imageConverter.ConvertTo(icon, typeof(Image));
            }
            catch (NotSupportedException)
            {
            }

            Win32.DestroyIcon(shinfo.iconHandle);
        }

        /// <summary>
        /// Gets the icon for this file item.
        /// </summary>
        public Image FileIconImage { get; }

        /// <summary>
        /// Gets the path to the directory.
        /// </summary>
        public string Path { get; }

        /// <summary>
        /// Gets the size on disc.
        /// </summary>
        public long SizeOnDisc => this.fileLength > 0 ? ((this.fileLength / SectorSize) + 1) * SectorSize : 0;

        /// <summary>
        /// Adds the file to the root <see cref="IFsiDirectoryItem"/>.
        /// </summary>
        /// <param name="rootItem">
        /// The root <see cref="IFsiDirectoryItem"/>.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/> result where true is success; false otherwise.
        /// </returns>
        public bool AddToFileSystem(IFsiDirectoryItem rootItem)
        {
            IStream stream = null;

            try
            {
                stream = Win32.LoadStream(this.Path);
                if (stream != null)
                {
                    rootItem.AddFile(this.displayName, stream);
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error adding file", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (stream != null)
                {
                    Marshal.FinalReleaseComObject(stream);
                }
            }

            return false;
        }

        /// <summary>
        /// Converts this object to a string for display.
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        public override string ToString()
        {
            return this.displayName;
        }
    }
}