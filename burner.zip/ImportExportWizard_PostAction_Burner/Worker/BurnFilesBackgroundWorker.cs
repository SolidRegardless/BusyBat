﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BurnFilesBackgroundWorker.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.Worker
{
    using System;
    using System.Linq;

    using ImportExportWizard_PostAction_Burner.Worker.Configuration;

    /// <summary>
    /// Background worker providing content burning functionality.
    /// </summary>
    public sealed class BurnFilesBackgroundWorker : BaseBackgroundWorker<BurnFilesConfigurationData>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BurnFilesBackgroundWorker"/> class.
        /// </summary>
        /// <param name="configuration">
        /// The configuration.
        /// </param>
        public BurnFilesBackgroundWorker(BurnFilesConfigurationData configuration)
            : this(null, configuration)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BurnFilesBackgroundWorker"/> class.
        /// </summary>
        /// <param name="mediaBurner">
        /// The media burner instance.
        /// </param>
        /// <param name="configuration">
        /// The configuration.
        /// </param>
        public BurnFilesBackgroundWorker(IMediaBurner mediaBurner, BurnFilesConfigurationData configuration)
            : base(mediaBurner, configuration)
        {
            this.Worker.DoWork += (sender, args) =>
            {
                this.Error = null;
                Console.Out.WriteLine("Burning files:");

                try
                {
                    var recorder = mediaBurner.RecordersInfo.First(x => x.Value.StartsWith(configuration.Recorder)).Key;

                    args.Result = mediaBurner.WriteContent(
                        clientName: "IMAPI2",
                        recorderDescriptor: recorder.ActiveDiscRecorder,
                        volumeLabel: configuration.VolumeLabel,
                        content: configuration.MediaItems,
                        forceClose: configuration.ForceClose,
                        speed: mediaBurner.GetSpeedDescriptors(recorder).Max(x => x.Key.WriteSpeed),
                        eject: configuration.Eject,
                        fileSystemFormat: configuration.FileSystems);
                }
                catch (Exception exception)
                {
                    this.Error = exception;

                    Console.Error.WriteLine(
                        $"Error ({exception.HResult}) during {nameof(BurnFilesBackgroundWorker)}::DoWork()");
                    Console.Error.WriteLine(exception.Message);

                    args.Result = exception.HResult;
                    if (!this.Worker.CancellationPending)
                    {
                        throw;
                    }

                    args.Result = -1;
                    args.Cancel = true;
                }
            };
        }

        /// <summary>
        /// Run the worker asynchronously using injecting parameters.
        /// </summary>
        /// <returns>
        /// Returns the background worker for linked queries.
        /// </returns>
        public override BaseBackgroundWorker<BurnFilesConfigurationData> RunAsync()
        {
            this.Worker.RunWorkerAsync();
            return this;
        }
    }
}