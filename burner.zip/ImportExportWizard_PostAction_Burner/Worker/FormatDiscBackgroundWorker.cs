﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="FormatDiscBackgroundWorker.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.Worker
{
    using System;
    using System.Linq;

    using ImportExportWizard_PostAction_Burner.Worker.Configuration;

    /// <summary>
    /// Background worker providing disc format functionality.
    /// </summary>
    public sealed class FormatDiscBackgroundWorker : BaseBackgroundWorker<FormatDiscConfigurationData>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FormatDiscBackgroundWorker"/> class.
        /// </summary>
        /// <param name="configuration">
        /// The configuration.
        /// </param>
        public FormatDiscBackgroundWorker(FormatDiscConfigurationData configuration)
            : base(null, configuration)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FormatDiscBackgroundWorker"/> class.
        /// </summary>
        /// <param name="mediaBurner">
        /// The media burner instance.
        /// </param>
        /// <param name="configuration">
        /// The configuration.
        /// </param>
        public FormatDiscBackgroundWorker(IMediaBurner mediaBurner, FormatDiscConfigurationData configuration)
            : base(mediaBurner, configuration)
        {
            this.Worker.DoWork += (sender, args) =>
            {
                this.Error = null;
                Console.Out.WriteLine("Formatting disc:");

                try
                {
                    var recorder = mediaBurner.RecordersInfo.First(x => x.Value.StartsWith(configuration.Recorder)).Key;

                    args.Result = 0;
                    if (!mediaBurner.IsMediaBlank(recorder))
                    {
                        args.Result = mediaBurner.FormatMedia(
                            recorderDescriptor: recorder.ActiveDiscRecorder,
                            clientName: "IMAPI2",
                            quick: configuration.Quick,
                            eject: configuration.Eject);
                    }
                }
                catch (Exception exception)
                {
                    this.Error = exception;
                    args.Result = exception.HResult;

                    Console.Error.WriteLine(
                        $"Error ({exception.HResult}) during {nameof(FormatDiscBackgroundWorker)}::DoWork()");
                    Console.Error.WriteLine(exception.Message);

                    args.Result = exception.HResult;
                    if (!this.Worker.CancellationPending)
                    {
                        throw;
                    }

                    args.Cancel = true;
                }
            };
        }

        /// <summary>
        /// Run the worker asynchronously using injecting parameters.
        /// </summary>
        /// <returns>
        /// Returns the background worker for linked queries.
        /// </returns>
        public override BaseBackgroundWorker<FormatDiscConfigurationData> RunAsync()
        {
            this.Worker.RunWorkerAsync();
            return this;
        }
    }
}