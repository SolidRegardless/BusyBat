﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BurnImageConfigurationData.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.Worker.Configuration
{
    /// <summary>
    /// The burn image configuration.
    /// </summary>
    public class BurnImageConfigurationData : BaseConfigurationData
    {
        /// <summary>
        /// Gets or sets the image file.
        /// </summary>
        public string ImageFile { get; set; }
    }
}