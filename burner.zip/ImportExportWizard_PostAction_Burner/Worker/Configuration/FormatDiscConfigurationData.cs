﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="FormatDiscConfigurationData.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.Worker.Configuration
{
    /// <summary>
    /// The format disc configuration.
    /// </summary>
    public class FormatDiscConfigurationData : BaseConfigurationData
    {
        /// <summary>
        /// Gets or sets a value indicating whether disc should be quick formatted.
        /// </summary>
        public bool Quick { get; set; }
    }
}