﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BaseConfigurationData.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.Worker.Configuration
{
    /// <summary>
    /// Base media configuration data.
    /// </summary>
    public abstract class BaseConfigurationData
    {
        /// <summary>
        /// Gets or sets a value indicating whether disc should be ejected.
        /// </summary>
        public bool Eject { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the media should be forcibly closed after
        /// the burn process completes.
        /// </summary>
        public bool ForceClose { get; set; }

        /// <summary>
        /// Gets or sets all or part of the recorder label to match for the target.
        /// </summary>
        public string Recorder { get; set; }
    }
}