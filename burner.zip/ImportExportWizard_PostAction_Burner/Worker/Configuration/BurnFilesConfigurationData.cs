﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BurnFilesConfigurationData.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.Worker.Configuration
{
    using ImportExportWizard_PostAction_Burner.Interop;
    using ImportExportWizard_PostAction_Burner.MediaItem;

    /// <summary>
    /// The burn files configuration.
    /// </summary>
    public class BurnFilesConfigurationData : BaseConfigurationData
    {
        /// <summary>
        /// Gets or sets the file systems to be created.
        /// </summary>
        public FsiFileSystems FileSystems { get; set; }

        /// <summary>
        /// Gets or sets the media items.
        /// </summary>
        public IMediaItem[] MediaItems { get; set; }

        /// <summary>
        /// Gets or sets the volume label.
        /// </summary>
        public string VolumeLabel { get; set; }
    }
}