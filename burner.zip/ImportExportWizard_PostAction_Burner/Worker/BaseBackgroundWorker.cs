﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BaseBackgroundWorker.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.Worker
{
    using System;
    using System.ComponentModel;
    using System.Threading.Tasks;

    /// <summary>
    /// Abstract media burner <see cref="BackgroundWorker"/>.
    /// </summary>
    /// <typeparam name="TParam">
    /// The type the supports the configuration of the sub class.
    /// </typeparam>
    public abstract class BaseBackgroundWorker<TParam>
    {
        /// <summary>
        /// Sleep between poll attempts for checking whether this worker is busy.
        /// </summary>
        private readonly TimeSpan busyCheckSleepDelay = TimeSpan.FromMilliseconds(50);

        /// <summary>
        /// The last result code.
        /// </summary>
        private int result;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseBackgroundWorker{TParam}"/> class.
        /// </summary>
        /// <param name="mediaBurner">
        /// The media burner instance.
        /// </param>
        /// <param name="configuration">
        /// The configuration of type <typeparamref name="TParam"/>.
        /// </param>
        protected BaseBackgroundWorker(IMediaBurner mediaBurner, TParam configuration)
        {
            this.Configuration = configuration;

            this.Worker = new BackgroundWorker { WorkerSupportsCancellation = true, WorkerReportsProgress = true };
            this.Worker.RunWorkerCompleted += (sender, args) =>
            {
                this.Result = args.Error?.HResult ?? Convert.ToInt32(args.Result);
            };

            this.MediaBurner = mediaBurner ?? new MediaBurner(this.Worker);
        }

        /// <summary>
        /// Gets or sets the processing <see cref="Exception"/>.
        /// </summary>
        public Exception Error { get; protected set; }

        /// <summary>
        /// Gets or sets the result.
        /// </summary>
        public int Result
        {
            get => this.result == 0 && this.Error != null ? this.Error.HResult : this.result;
            set => this.result = value;
        }

        /// <summary>
        /// Gets the <see cref="IMediaBurner"/> instance associated with this worker.
        /// </summary>
        public IMediaBurner MediaBurner { get; }

        /// <summary>
        /// Gets the configuration for this worker.
        /// </summary>
        public TParam Configuration { get; }

        /// <summary>
        /// Gets the background worker.
        /// </summary>
        public BackgroundWorker Worker { get; }

        /// <summary>
        /// Run the worker asynchronously using injecting parameters.
        /// </summary>
        /// <returns>
        /// Returns the background worker for linked queries.
        /// </returns>
        public abstract BaseBackgroundWorker<TParam> RunAsync();

        /// <summary>
        /// Task that loops until the <see cref="BackgroundWorker"/> is no longer busy.
        /// </summary>
        /// <param name="handler">
        /// The progress changed handler.
        /// </param>
        /// <returns>
        /// Returns the asynchronous <see cref="Task"/> that can be awaited upon.
        /// </returns>
        public async Task WhileBusy(ProgressChangedEventHandler handler)
        {
            if (handler != null)
            {
                this.Worker.ProgressChanged += handler;
            }

            try
            {
                while (this.Worker.IsBusy)
                {
                    await Task.Delay(this.busyCheckSleepDelay);
                }
            }
            finally
            {
                if (handler != null)
                {
                    this.Worker.ProgressChanged -= handler;
                }
            }
        }
    }
}