﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MediaBurner.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Runtime.InteropServices.ComTypes;
    using System.Text;
    using System.Threading;

    using ImportExportWizard_PostAction_Burner.Interop;
    using ImportExportWizard_PostAction_Burner.MediaItem;

    /// <summary>
    /// Implementation of a media burner providing a wrapper on the IMAPI2 interop to give
    /// CD, DVD and BluRay format, ISO generation and burning support.
    /// </summary>
    public class MediaBurner : IMediaBurner
    {
        /// <summary>
        /// Delay before retrying an disc IO operation.
        /// </summary>
        private readonly TimeSpan statusRetryDelay = TimeSpan.FromMilliseconds(2500);

        /// <summary>
        /// The background worker instance.
        /// </summary>
        private readonly BackgroundWorker backgroundWorker;

        /// <summary>
        /// The list of disc recorders reported by the system.
        /// </summary>
        private readonly List<MsftDiscRecorder2> recorders;

        /// <summary>
        /// Initializes a new instance of the <see cref="MediaBurner"/> class.
        /// </summary>
        public MediaBurner()
        {
            var discMaster = new MsftDiscMaster2();

            try
            {
                this.recorders = new List<MsftDiscRecorder2>();
                for (var i = 0; i < discMaster.Count; ++i)
                {
                    var mi = new MsftDiscFormat2Data();
                    try
                    {
                        var rec = new MsftDiscRecorder2();

                        rec.InitializeDiscRecorder(discMaster[i]);
                        mi.Recorder = rec;

                        if (mi.IsRecorderSupported(rec))
                        {
                            this.recorders.Add(rec);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.Error.WriteLine($"Error ({ex.HResult}) while querying recorder: {discMaster[i] ?? "N/A"}");
                        Console.Error.WriteLine(ex.Message);

                        throw;
                    }
                    finally
                    {
                        Marshal.FinalReleaseComObject(mi);
                    }
                }
            }
            finally
            {
                Marshal.FinalReleaseComObject(discMaster);
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MediaBurner"/> class.
        /// </summary>
        /// <param name="backgroundWorker">
        /// The background worker.
        /// </param>
        public MediaBurner(BackgroundWorker backgroundWorker)
            : this()
        {
            this.backgroundWorker = backgroundWorker;
        }

        /// <summary>
        /// Gets a list of recorder information.
        /// </summary>
        public IList<KeyValuePair<MsftDiscRecorder2, string>> RecordersInfo
        {
            get
            {
                var list = new List<KeyValuePair<MsftDiscRecorder2, string>>();
                this.recorders.ForEach(
                    delegate(MsftDiscRecorder2 rec)
                    {
                        var descr = $"{rec.VolumePathNames.First()}[{rec.ProductId}] ";
                        list.Add(new KeyValuePair<MsftDiscRecorder2, string>(rec, descr));
                    });
                return list.Count > 0 ? list : null;
            }
        }

        /// <summary>
        /// Gets whether the media can be written to.
        /// </summary>
        /// <param name="rec">
        /// The recorder containing the media in question.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/> result indicating true if it can be written to; false otherwise.
        /// </returns>
        public bool CanWriteMedia(MsftDiscRecorder2 rec)
        {
            var mi = new MsftDiscFormat2Data();
            try
            {
                mi.Recorder = rec;
                return mi.IsRecorderSupported(rec) && mi.IsCurrentMediaSupported(rec);
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Error ({ex.HResult}) checking if recorder or media is supported");
                Console.Error.WriteLine(ex.Message);

                return false;
            }
            finally
            {
                Marshal.FinalReleaseComObject(mi);
            }
        }

        /// <summary>
        /// Create a <see cref="IStream"/> for the array of <see cref="IMediaItem"/> objects.
        /// </summary>
        /// <param name="discRecorder">
        /// The <see cref="IDiscRecorder2"/> to target creation for.
        /// </param>
        /// <param name="volumeName">
        /// Name of the label to give the stream.
        /// </param>
        /// <param name="mediaItems">
        /// The media items to create the image from.
        /// </param>
        /// <param name="multisessionInterfaces">
        /// Any multi session interfaces to take into consideration.
        /// </param>
        /// <param name="fileSystemFormat">
        /// The file system format that will be created.
        /// </param>
        /// <param name="dataStream">
        /// The resulting <see cref="IStream"/>.
        /// </param>
        /// <returns>
        /// Returns a <see cref="bool"/> indicating success when true; false otherwise.
        /// </returns>
        public bool CreateMediaFileSystem(
            IDiscRecorder2 discRecorder,
            string volumeName,
            IMediaItem[] mediaItems,
            object[] multisessionInterfaces,
            FsiFileSystems fileSystemFormat,
            out IStream dataStream)
        {
            MsftFileSystemImage fileSystemImage = null;
            try
            {
                fileSystemImage = new MsftFileSystemImage();
                fileSystemImage.Update += this.UpdateFileSystemImage;

                fileSystemImage.ChooseImageDefaults(discRecorder);
                fileSystemImage.FileSystemsToCreate = fileSystemFormat;
                fileSystemImage.VolumeName = volumeName;

                if (multisessionInterfaces != null)
                {
                    fileSystemImage.MultisessionInterfaces = multisessionInterfaces;
                    fileSystemImage.ImportFileSystem();
                }

                IFsiDirectoryItem rootItem = fileSystemImage.Root;
                foreach (IMediaItem mediaItem in mediaItems)
                {
                    if (this.backgroundWorker.CancellationPending)
                    {
                        break;
                    }

                    mediaItem.AddToFileSystem(rootItem);
                }

                if (this.backgroundWorker.CancellationPending)
                {
                    dataStream = null;
                    return false;
                }

                dataStream = fileSystemImage.CreateResultImage().ImageStream;
            }
            catch (COMException exception)
            {
                Console.Error.WriteLine($"Error ({exception.HResult}) trying to create media file system");
                Console.Error.WriteLine(exception.Message);

                dataStream = null;
                return false;
            }
            finally
            {
                if (fileSystemImage != null)
                {
                    fileSystemImage.Update -= this.UpdateFileSystemImage;
                    Marshal.ReleaseComObject(fileSystemImage);
                }
            }

            return true;
        }

        /// <summary>
        /// Gets the current physical media type for the given recorder.
        /// </summary>
        /// <param name="rec">
        /// The recorder in question.
        /// </param>
        /// <returns>
        /// Returns the <see cref="IMAPI_MEDIA_PHYSICAL_TYPE"/>.
        /// </returns>
        public IMAPI_MEDIA_PHYSICAL_TYPE CurrentPhysicalMediaType(MsftDiscRecorder2 rec)
        {
            var mi = new MsftDiscFormat2Data();
            try
            {
                mi.Recorder = rec;
                return mi.CurrentPhysicalMediaType;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine($"Error ({exception.HResult}) trying to query physical media type");
                Console.Error.WriteLine(exception.Message);

                return IMAPI_MEDIA_PHYSICAL_TYPE.IMAPI_MEDIA_TYPE_UNKNOWN;
            }
            finally
            {
                Marshal.FinalReleaseComObject(mi);
            }
        }

        /// <summary>
        /// Format the media contained within the recorder specified by the unique descriptor.
        /// </summary>
        /// <param name="recorderDescriptor">
        /// The disc recorder unique descriptor.
        /// </param>
        /// <param name="clientName">
        /// The client name requiring exclusive access to the recorder (IMAPI2 usually).
        /// </param>
        /// <param name="quick">
        /// Whether a quick format should be done.
        /// </param>
        /// <param name="eject">
        /// Whether the media should be ejected after the process completes.
        /// </param>
        /// <returns>
        /// Returns the exit code where 0 indicates success; otherwise fail.
        /// </returns>
        public int FormatMedia(string recorderDescriptor, string clientName, bool quick, bool eject)
        {
            int exitCode;
            MsftDiscFormat2Erase discFormatErase = null;
            MsftDiscRecorder2 discRecorder = null;

            try
            {
                discRecorder = new MsftDiscRecorder2();
                discRecorder.InitializeDiscRecorder(recorderDescriptor);
                discRecorder.AcquireExclusiveAccess(true, clientName);

                discFormatErase = new MsftDiscFormat2Erase
                {
                    Recorder = discRecorder,
                    ClientName = clientName,
                    FullErase = !quick
                };

                discFormatErase.Update += this.UpdateDiscFormatEraseData;
                discFormatErase.EraseMedia();

                if (eject)
                {
                    Thread.Sleep(2000);
                    if (!this.backgroundWorker.CancellationPending)
                    {
                        discRecorder.EjectMedia();
                    }
                }

                exitCode = 0;
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine($"Error ({exception.HResult}) trying to format the disc");
                Console.Error.WriteLine(exception.Message);

                exitCode = exception.HResult;
            }
            finally
            {
                if (discFormatErase != null)
                {
                    discFormatErase.Update -= this.UpdateDiscFormatEraseData;
                }

                if (discFormatErase != null)
                {
                    Marshal.FinalReleaseComObject(discFormatErase);
                }

                if (discRecorder != null)
                {
                    discRecorder.ReleaseExclusiveAccess();
                    Marshal.FinalReleaseComObject(discRecorder);
                }
            }

            return exitCode;
        }

        /// <summary>
        /// Gets the media state description for the given recorder.
        /// </summary>
        /// <param name="rec">
        /// The recorder in question.
        /// </param>
        /// <returns>
        /// The <see cref="string"/> description.
        /// </returns>
        public string GetMediaStateDescription(MsftDiscRecorder2 rec)
        {
            var sb = new StringBuilder("Media type:");
            var mi = new MsftDiscFormat2Data();

            try
            {
                mi.Recorder = rec;
                for (var i = 1; i <= (int)mi.CurrentMediaStatus; i <<= 1)
                {
                    if (((int)mi.CurrentMediaStatus & i) != i)
                    {
                        continue;
                    }

                    sb.Append(EnumHelper.GetDescription((IMAPI_FORMAT2_DATA_MEDIA_STATE)i));
                    sb.Append('|');
                }

                sb.Remove(sb.Length - 1, 1);
                return sb.ToString();
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine($"Error ({exception.HResult}) getting media state description;");
                Console.Error.WriteLine("Possibly because there is no media or the selected drive is not a recorder.");
                Console.Error.WriteLine(exception.Message);

                throw;
            }
            finally
            {
                Marshal.FinalReleaseComObject(mi);
                sb.Length = 0;
            }
        }

        /// <summary>
        /// Gets a list of general media types supported by recorders.
        /// </summary>
        /// <returns>
        /// The list of physical media type keypair descriptions.
        /// </returns>
        public IList<KeyValuePair<IMAPI_MEDIA_PHYSICAL_TYPE, string>> GetMediaTypes()
        {
            var mediaTypes = EnumHelper.EnumToList<IMAPI_MEDIA_PHYSICAL_TYPE>();

            mediaTypes.RemoveAt(mediaTypes.Count - 1);
            mediaTypes.RemoveAt(0);

            return mediaTypes;
        }

        /// <summary>
        /// Gets a list of write speed descriptors for the specified recorder.
        /// </summary>
        /// <param name="rec">
        /// The recorder in question.
        /// </param>
        /// <returns>
        /// The list of write speed descriptor keypairs.
        /// </returns>
        public IList<KeyValuePair<IWriteSpeedDescriptor, string>> GetSpeedDescriptors(MsftDiscRecorder2 rec)
        {
            List<KeyValuePair<IWriteSpeedDescriptor, string>> list;
            var mi = new MsftDiscFormat2Data();

            try
            {
                mi.Recorder = rec;

                var speedDescriptors = mi.SupportedWriteSpeedDescriptors;
                var enumerator = speedDescriptors.GetEnumerator();

                list = new List<KeyValuePair<IWriteSpeedDescriptor, string>>(speedDescriptors.GetLength(0));
                while (enumerator.MoveNext())
                {
                    if (enumerator.Current is IWriteSpeedDescriptor spd)
                    {
                        list.Add(new KeyValuePair<IWriteSpeedDescriptor, string>(spd, spd.WriteSpeed.ToString()));
                    }
                }
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine($"Error ({exception.HResult}) getting the speed descriptors");
                Console.Error.WriteLine(exception.Message);

                throw;
            }
            finally
            {
                Marshal.FinalReleaseComObject(mi);
            }

            return (list.Count > 0) ? list : null;
        }

        /// <summary>
        /// Gets whether the media is blank in the specified recorder.
        /// </summary>
        /// <param name="rec">
        /// The recorder in question.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/> result indicating true if blank; false otherwise.
        /// </returns>
        public bool IsMediaBlank(MsftDiscRecorder2 rec)
        {
            var mediaData = new MsftDiscFormat2Data();
            try
            {
                mediaData.Recorder = rec;
                return mediaData.MediaPhysicallyBlank || mediaData.MediaHeuristicallyBlank;
            }
            catch
            {
                return false;
            }
            finally
            {
                Marshal.FinalReleaseComObject(mediaData);
            }
        }

        /// <summary>
        /// Gets the supported media types for the specified recorder.
        /// </summary>
        /// <param name="rec">
        /// The recorder in question.
        /// </param>
        /// <returns>
        /// Returns the <see cref="List{IMAPI_MEDIA_PHYSICAL_TYPE}"/>.
        /// </returns>
        public List<IMAPI_MEDIA_PHYSICAL_TYPE> SupportedMediaTypes(MsftDiscRecorder2 rec)
        {
            var mediaData = new MsftDiscFormat2Data();
            try
            {
                mediaData.Recorder = rec;
                var list = new List<IMAPI_MEDIA_PHYSICAL_TYPE>(mediaData.SupportedMediaTypes.Length);

                foreach (IMAPI_MEDIA_PHYSICAL_TYPE mediaType in mediaData.SupportedMediaTypes)
                {
                    list.Add(mediaType);
                }

                return list;
            }
            finally
            {
                Marshal.FinalReleaseComObject(mediaData);
            }
        }

        /// <summary>
        /// Update called when the status/progress of a disc format changes.
        /// </summary>
        /// <param name="sender">
        /// Sender of the update.
        /// </param>
        /// <param name="prog">
        /// The progress data.
        /// </param>
        public void UpdateDiscFormatData(
            [In, MarshalAs(UnmanagedType.IDispatch)]
            object sender,
            [In, MarshalAs(UnmanagedType.IDispatch)]
            object prog)
        {
            var format2Data = sender as IDiscFormat2Data;
            if (this.backgroundWorker.CancellationPending)
            {
                try
                {
                    format2Data?.CancelWrite();
                }
                catch (Exception ex)
                {
                    Debug.Assert(ex == null, "ex == null");
                }

                this.backgroundWorker.ReportProgress(100, "User cancelling...");
                return;
            }

            var percentDone = 0;
            try
            {
                string timeStatus;
                var progress = (IDiscFormat2DataEventArgs)prog;
                var currentWriteSpeed = format2Data?.CurrentWriteSpeed ?? 0;
                var remainingTime =
                    $"{progress.RemainingTime / 3600:##}:{(progress.RemainingTime / 60) % 60:##}:{progress.RemainingTime % 60:##}";

                switch (progress.CurrentAction)
                {
                    case IMAPI_FORMAT2_DATA_WRITE_ACTION.IMAPI_FORMAT2_DATA_WRITE_ACTION_VALIDATING_MEDIA:
                        percentDone = 0;
                        timeStatus = $"Validating media: {percentDone}%, time left: {remainingTime}";
                        break;
                    case IMAPI_FORMAT2_DATA_WRITE_ACTION.IMAPI_FORMAT2_DATA_WRITE_ACTION_FORMATTING_MEDIA:
                        percentDone = 0;
                        timeStatus = $"Formatting media: {percentDone}%, time left: {remainingTime}";
                        break;
                    case IMAPI_FORMAT2_DATA_WRITE_ACTION.IMAPI_FORMAT2_DATA_WRITE_ACTION_INITIALIZING_HARDWARE:
                        percentDone = 0;
                        timeStatus = $"Initialising Hardware: {percentDone}%, time left: {remainingTime}";
                        break;
                    case IMAPI_FORMAT2_DATA_WRITE_ACTION.IMAPI_FORMAT2_DATA_WRITE_ACTION_CALIBRATING_POWER:
                        percentDone = 0;
                        timeStatus =
                            $"Calibrating Power (OPC): {percentDone}% at {currentWriteSpeed}KB/s, time left: {remainingTime}";
                        break;
                    case IMAPI_FORMAT2_DATA_WRITE_ACTION.IMAPI_FORMAT2_DATA_WRITE_ACTION_WRITING_DATA:
                        percentDone = ((progress.LastWrittenLba - progress.StartLba) * 100) / progress.SectorCount;
                        if (progress.SectorCount > 0)
                        {
                            timeStatus =
                                $"Progress writing: {percentDone}% at {currentWriteSpeed}KB/s, time left: {remainingTime}";
                        }
                        else
                        {
                            timeStatus = $"Progress writing: 0% at {currentWriteSpeed}KB/s";
                            percentDone = 0;
                        }

                        break;
                    case IMAPI_FORMAT2_DATA_WRITE_ACTION.IMAPI_FORMAT2_DATA_WRITE_ACTION_FINALIZATION:
                        percentDone = 100;
                        timeStatus =
                            $"Finalizing the writing: {percentDone}% at {currentWriteSpeed}KB/s, time left: {remainingTime}";
                        break;
                    case IMAPI_FORMAT2_DATA_WRITE_ACTION.IMAPI_FORMAT2_DATA_WRITE_ACTION_COMPLETED:
                        percentDone = 100;
                        timeStatus =
                            $"Completed the burn: {percentDone}% at {currentWriteSpeed}KB/s, time left: {remainingTime}";
                        break;
                    case IMAPI_FORMAT2_DATA_WRITE_ACTION.IMAPI_FORMAT2_DATA_WRITE_ACTION_VERIFYING:
                        percentDone = 100;
                        timeStatus =
                            $"Verifying write: {percentDone}% at {currentWriteSpeed}KB/s, time left: {remainingTime}";
                        break;
                    default:
                        timeStatus = "Unknown action: " + progress.CurrentAction;
                        break;
                }

                this.backgroundWorker.ReportProgress(Convert.ToInt32(percentDone), timeStatus);
            }
            catch (Exception exception)
            {
                Console.Error.WriteLine($"Error ({exception.HResult}) updating the disc format/burn status message");
                Console.Error.WriteLine(exception.Message);

                this.backgroundWorker.ReportProgress(Convert.ToInt32(percentDone), exception.Message);
            }
        }

        /// <summary>
        /// Update called when the status/progress of a disc erase changes.
        /// </summary>
        /// <param name="sender">
        /// Sender of the update.
        /// </param>
        /// <param name="elapsedSeconds">
        /// Seconds elapsed.
        /// </param>
        /// <param name="estimatedTotalSeconds">
        /// Estimated total seconds until complete.
        /// </param>
        public void UpdateDiscFormatEraseData(
            [In, MarshalAs(UnmanagedType.IDispatch)]
            object sender,
            int elapsedSeconds,
            int estimatedTotalSeconds)
        {
            if (this.backgroundWorker.CancellationPending)
            {
                this.backgroundWorker.ReportProgress(100, 0);
                try
                {
                    if (sender is IDiscFormat2Erase discFormatErase)
                    {
                        Marshal.FinalReleaseComObject(discFormatErase);
                    }
                }
                catch (Exception exception)
                {
                    Console.Error.WriteLine($"Error ({exception.HResult}) releasing the IDiscFormat2Erase object");
                    Console.Error.WriteLine(exception.Message);

                    Debug.Assert(exception == null, "ex == null");
                }

                return;
            }

            this.backgroundWorker.ReportProgress(elapsedSeconds, estimatedTotalSeconds);
        }

        /// <summary>
        /// Handle an update event raised from the <see cref="IFileSystemImage"/> instance.
        /// </summary>
        /// <param name="sender">
        /// Sender of the event.
        /// </param>
        /// <param name="currentFile">
        /// The file being processed.
        /// </param>
        /// <param name="copiedSectors">
        /// Total sectors copied.
        /// </param>
        /// <param name="totalSectors">
        /// Total sectors to copy.
        /// </param>
        public void UpdateFileSystemImage(
            [In, MarshalAs(UnmanagedType.IDispatch)]
            object sender,
            [In, MarshalAs(UnmanagedType.BStr)] string currentFile,
            [In] int copiedSectors,
            [In] int totalSectors)
        {
            var percentProgress = 0;
            if (copiedSectors > 0 && totalSectors > 0)
            {
                percentProgress = (copiedSectors * 100) / totalSectors;
            }

            if (!string.IsNullOrEmpty(currentFile))
            {
                var fileInfo = new FileInfo(currentFile);
                this.backgroundWorker.ReportProgress(percentProgress, $"Adding \"{fileInfo.Name}\" to image...");
            }
        }

        /// <summary>
        /// Write the provided array of <see cref="IMediaItem"/> items using the specified recorder.
        /// </summary>
        /// <param name="clientName">
        /// Client name that will obtain an exclusive lock on the recorder while recording.
        /// </param>
        /// <param name="recorderDescriptor">
        /// The recorder descriptor to use to burn the media.
        /// </param>
        /// <param name="volumeLabel">
        /// The volume label for the disc.
        /// </param>
        /// <param name="content">
        /// The media content to write.
        /// </param>
        /// <param name="forceClose">
        /// Should the disc be forcibly closed at the end of the burn process?
        /// </param>
        /// <param name="speed">
        /// The burn speed.
        /// </param>
        /// <param name="eject">
        /// Should the disc be ejected after the burn process has completed?
        /// </param>
        /// <param name="fileSystemFormat">
        /// The file system format for the created disc.
        /// </param>
        /// <returns>
        /// Return the exit code where 0 is success; failed otherwise.
        /// </returns>
        public int WriteContent(
            string clientName,
            string recorderDescriptor,
            string volumeLabel,
            IMediaItem[] content,
            bool forceClose,
            int speed,
            bool eject,
            FsiFileSystems fileSystemFormat = FsiFileSystems.FsiFileSystemISO9660 | FsiFileSystems.FsiFileSystemJoliet)
        {
            MsftDiscRecorder2 discRecorder = null;
            MsftDiscFormat2Data discFormatData = null;

            try
            {
                discRecorder = new MsftDiscRecorder2();
                discRecorder.InitializeDiscRecorder(recorderDescriptor);

                discFormatData = new MsftDiscFormat2Data
                {
                    Recorder = discRecorder,
                    ClientName = clientName,
                    ForceMediaToBeClosed = forceClose
                };

                // ReSharper disable once SuspiciousTypeConversion.Global
                var burnVerification = (IBurnVerification)discFormatData;
                burnVerification.BurnVerificationLevel = IMAPI_BURN_VERIFICATION_LEVEL.IMAPI_BURN_VERIFICATION_NONE;

                object[] multisessionInterfaces = null;
                if (!discFormatData.MediaHeuristicallyBlank)
                {
                    multisessionInterfaces = discFormatData.MultisessionInterfaces;
                }

                IStream fileSystem;
                if (!this.CreateMediaFileSystem(
                    discRecorder,
                    volumeLabel,
                    content,
                    multisessionInterfaces,
                    fileSystemFormat,
                    out fileSystem))
                {
                    return -1;
                }

                try
                {
                    discFormatData.Update += this.UpdateDiscFormatData;
                    discFormatData.Write(fileSystem);
                }
                catch (COMException exception)
                {
                    Console.Error.WriteLine($"Error ({exception.HResult}) writing the file system data to disc");
                    Console.Error.WriteLine(exception.Message);

                    return exception.ErrorCode;
                }
                finally
                {
                    discFormatData.Update -= this.UpdateDiscFormatData;
                    if (fileSystem != null)
                    {
                        Marshal.FinalReleaseComObject(fileSystem);
                    }
                }

                try
                {
                    if (eject)
                    {
                        this.WaitThenEjectDisc(discFormatData, discRecorder);
                    }
                }
                catch (Exception exception)
                {
                    Console.Error.WriteLine($"Error ({exception.HResult}) trying to eject the disc");
                    Console.Error.WriteLine(exception.Message);

                    throw;
                }

                return 0;
            }
            catch (COMException exception)
            {
                Console.Error.WriteLine(
                    $"General error ({exception.HResult}) during the preparation for writing file system data to disc");
                Console.Error.WriteLine(exception.Message);

                return exception.ErrorCode;
            }
            finally
            {
                if (discRecorder != null)
                {
                    Marshal.ReleaseComObject(discRecorder);
                }

                if (discFormatData != null)
                {
                    Marshal.ReleaseComObject(discFormatData);
                }
            }
        }

        /// <summary>
        /// Write the specified stream to the media contained within the specified recorder.
        /// </summary>
        /// <param name="stream">
        /// The stream to write to the media.
        /// </param>
        /// <param name="recorderDescriptor">
        /// The disc recorder unique descriptor.
        /// </param>
        /// <param name="clientName">
        /// The client name requiring exclusive access to the recorder (IMAPI2 usually).
        /// </param>
        /// <param name="forceClose">
        /// Whether the media should be forced to close.
        /// </param>
        /// <param name="speed">
        /// The indicated speed at which the write should be performed at if possible.
        /// </param>
        /// <param name="eject">
        /// Whether the media should be ejected after the process completes.
        /// </param>
        /// <returns>
        /// The <see cref="int"/> status where 0 is success; otherwise an error occurred.
        /// </returns>
        public int WriteStream(
            IStream stream,
            string recorderDescriptor,
            string clientName,
            bool forceClose,
            int speed,
            bool eject)
        {
            MsftDiscRecorder2 discRecorder = null;
            MsftDiscFormat2Data discFormatData = null;
            int result;

            try
            {
                discRecorder = new MsftDiscRecorder2();
                discRecorder.InitializeDiscRecorder(recorderDescriptor);
                discFormatData = new MsftDiscFormat2Data { Recorder = discRecorder };
                discFormatData.Update += this.UpdateDiscFormatData;

                try
                {
                    this.AquireExclusiveAccessAndWriteStream(
                        stream,
                        clientName,
                        forceClose,
                        speed,
                        discRecorder,
                        discFormatData);
                }
                catch (Exception exception)
                {
                    Console.Error.WriteLine($"Error ({exception.HResult}) trying to write the stream to disc");
                    Console.Error.WriteLine(exception.Message);

                    throw;
                }

                if (this.backgroundWorker.CancellationPending)
                {
                    return 1;
                }

                try
                {
                    if (eject)
                    {
                        this.WaitThenEjectDisc(discFormatData, discRecorder);
                    }
                }
                catch (Exception exception)
                {
                    Console.Error.WriteLine($"Error ({exception.HResult}) trying to eject the disc");
                    Console.Error.WriteLine(exception.Message);

                    throw;
                }

                result = 0;
            }
            catch (Exception exception)
            {
                result = exception.HResult;
            }
            finally
            {
                if (this.backgroundWorker.CancellationPending)
                {
                    result = 1;
                }

                if (discFormatData != null)
                {
                    discFormatData.Update -= this.UpdateDiscFormatData;
                    Marshal.FinalReleaseComObject(discFormatData);
                }

                if (discRecorder != null)
                {
                    discRecorder.ReleaseExclusiveAccess();
                    Marshal.FinalReleaseComObject(discRecorder);
                }
            }

            return result;
        }

        /// <summary>
        /// Wait for an appropriate status and then eject the disc from the recorder.
        /// </summary>
        /// <param name="discFormat">
        /// The <see cref="MsftDiscFormat2Data"/> instance.
        /// </param>
        /// <param name="discRecorder">
        /// The <see cref="MsftDiscRecorder2"/> instance.
        /// </param>
        private void WaitThenEjectDisc(MsftDiscFormat2Data discFormat, MsftDiscRecorder2 discRecorder)
        {
            var state = IMAPI_FORMAT2_DATA_MEDIA_STATE.IMAPI_FORMAT2_DATA_MEDIA_STATE_UNKNOWN;
            while (state == IMAPI_FORMAT2_DATA_MEDIA_STATE.IMAPI_FORMAT2_DATA_MEDIA_STATE_UNKNOWN
                && !this.backgroundWorker.CancellationPending)
            {
                try
                {
                    state = discFormat.CurrentMediaStatus;
                }
                catch (Exception exception)
                {
                    Console.Error.WriteLine($"Error ({exception.HResult}) trying to get the current media status");
                    Console.Error.WriteLine(exception.Message);

                    state = IMAPI_FORMAT2_DATA_MEDIA_STATE.IMAPI_FORMAT2_DATA_MEDIA_STATE_UNKNOWN;
                    Thread.Sleep(this.statusRetryDelay);
                }
            }

            if (!this.backgroundWorker.CancellationPending)
            {
                discRecorder.EjectMedia();
            }
        }

        /// <summary>
        /// Acquire exclusive access and then write the stream to disc.
        /// </summary>
        /// <param name="stream">
        /// The stream to write.
        /// </param>
        /// <param name="clientName">
        /// The client name that wishes to acquire the exclusive lock.
        /// </param>
        /// <param name="forceClose">
        /// Should the disc be forcibly closed after the write process.
        /// </param>
        /// <param name="speed">
        /// The speed at which to write to disc.
        /// </param>
        /// <param name="discRecorder">
        /// The <see cref="MsftDiscRecorder2"/> instance.
        /// </param>
        /// <param name="discFormat">
        /// The <see cref="MsftDiscFormat2Data"/> instance.
        /// </param>
        private void AquireExclusiveAccessAndWriteStream(
            IStream stream,
            string clientName,
            bool forceClose,
            int speed,
            MsftDiscRecorder2 discRecorder,
            MsftDiscFormat2Data discFormat)
        {
            discRecorder.AcquireExclusiveAccess(true, clientName);

            discFormat.ClientName = clientName;
            discFormat.ForceMediaToBeClosed = forceClose;
            discFormat.SetWriteSpeed(speed, true);

            discFormat.Write(stream);
        }
    }
}