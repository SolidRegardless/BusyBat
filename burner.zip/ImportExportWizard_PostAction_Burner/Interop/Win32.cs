﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Win32.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.Interop
{
    using System;
    using System.Runtime.InteropServices;
    using System.Runtime.InteropServices.ComTypes;

    /// <summary>
    /// Win2 P/Invoke helper functions.
    /// </summary>
    public sealed class Win32
    {
        /// <summary>
        /// Mask for normal file attributes.
        /// </summary>
        public const uint FileAttributeNormal = 0x00000080;

        /// <summary>
        /// Mask for getting file information icon.
        /// </summary>
        public const uint ShellGetFileInformationIcon = 0x100;

        /// <summary>
        /// Mask for getting file information large icon.
        /// </summary>
        public const uint ShellGetFileInformationLargeIcon = 0x0;

        /// <summary>
        /// Mask for getting file information small icon.
        /// </summary>
        public const uint ShellGetFileInformationSmallIcon = 0x1;

        /// <summary>
        /// Mask for deleting upon release.
        /// </summary>
        public const uint ShellDeleteOnRelease = 0x04000000;

        /// <summary>
        /// Mask for reading.
        /// </summary>
        public const uint ShellRead = 0x00000000;

        /// <summary>
        /// Mask for share deny none.
        /// </summary>
        public const uint ShellShareDenyNone = 0x00000040;

        /// <summary>
        /// Mask for share deny write.
        /// </summary>
        public const uint ShellShareDenyWrite = 0x00000020;

        /// <summary>
        /// Destroy the icon specified by the handle.
        /// </summary>
        /// <param name="handle">
        /// The handle to the icon
        /// </param>
        /// <returns>
        /// The <see cref="bool"/> result.
        /// </returns>
        [DllImport("user32.dll")]
        public static extern bool DestroyIcon(IntPtr handle);

        /// <summary>
        /// Load the specified file into a COM stream.
        /// </summary>
        /// <param name="file">
        /// The file to read.
        /// </param>
        /// <returns>
        /// The <see cref="IStream"/>.
        /// </returns>
        /// <exception cref="COMException">
        /// Thrown if unable to open the file.
        /// </exception>
        public static IStream LoadStream(string file)
        {
            var result = SHCreateStreamOnFile(file, ShellShareDenyWrite, out IStream newStream);
            if (result != 0 || newStream == null)
            {
                throw new COMException("can't open " + file + " as IStream", result);
            }

            return newStream;
        }

        /// <summary>
        /// Get file information using the Win32 shell library.
        /// </summary>
        /// <param name="path">
        /// The path to the file.
        /// </param>
        /// <param name="attributes">
        /// The file attributes mask.
        /// </param>
        /// <param name="fileInfo">
        /// The shell file information structure.
        /// </param>
        /// <param name="sizeFileInfo">
        /// The size of the file info structure.
        /// </param>
        /// <param name="flags">
        /// The flags for getting the file information.
        /// </param>
        /// <returns>
        /// The <see cref="IntPtr"/> result.
        /// </returns>
        [DllImport("shell32.dll")]
        public static extern IntPtr SHGetFileInfo(
            string path,
            uint attributes,
            ref Shell32FileInfo fileInfo,
            uint sizeFileInfo,
            uint flags);

        /// <summary>
        /// Create stream for the given file.
        /// </summary>
        /// <param name="path">
        /// The path to the file.
        /// </param>
        /// <param name="mode">
        /// The read file mode.
        /// </param>
        /// <param name="stream">
        /// The out stream parameter.
        /// </param>
        /// <returns>
        /// The <see cref="int"/> result.
        /// </returns>
        [DllImport("shlwapi.dll", CharSet = CharSet.Unicode)]
        public static extern int SHCreateStreamOnFile(string path, uint mode, out IStream stream);
    }
}