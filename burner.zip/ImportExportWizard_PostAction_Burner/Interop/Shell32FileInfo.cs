﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Shell32FileInfo.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.Interop
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Runtime.InteropServices;

    /// <summary>
    /// Win32 shell file info.
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    [SuppressMessage("ReSharper", "StyleCop.SA1307", Justification = "P/Invoke structure")]
    public struct Shell32FileInfo
    {
        /// <summary>
        /// The handle to the icon.
        /// </summary>
        public IntPtr iconHandle;

        /// <summary>
        /// The icon size.
        /// </summary>
        public IntPtr iconSize;

        /// <summary>
        /// The file attributes.
        /// </summary>
        public uint attributes;

        /// <summary>
        /// The display name.
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string displayName;

        /// <summary>
        /// The type name.
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
        public string typeName;
    };
}