﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EnumHelper.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_Burner.Interop
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Globalization;

    /// <summary>
    /// The enumeration helper.
    /// </summary>
    public static class EnumHelper
    {
        /// <summary>
        /// The enumeration to list converter.
        /// </summary>
        /// <typeparam name="T">
        /// Enumeration type.
        /// </typeparam>
        /// <returns>
        /// The <see cref="IList{T}"/>.
        /// </returns>
        /// <exception cref="ArgumentNullException">
        /// Type is not identifiable.
        /// </exception>
        /// <exception cref="ApplicationException">
        /// Type is not an enumeration.
        /// </exception>
        public static IList<KeyValuePair<T, string>> EnumToList<T>()
        {
            var type = typeof(T);
            if (type == null)
            {
                throw new ArgumentNullException(nameof(type));
            }

            if (!type.IsEnum)
            {
                throw new ApplicationException("Argument must be enum");
            }

            var enumValues = Enum.GetValues(type);
            var list = new List<KeyValuePair<T, string>>(enumValues.GetLength(0));
            foreach (Enum value in enumValues)
            {
                list.Add(
                    new KeyValuePair<T, string>(
                        (T)Convert.ChangeType(value, typeof(T), CultureInfo.InvariantCulture),
                        GetDescription(value)));
            }

            return list;
        }

        /// <summary>
        /// Get the description pertaining to the enumeration value (if applicable).
        /// </summary>
        /// <param name="value">
        /// The value to reflect the description to.
        /// </param>
        /// <returns>
        /// The <see cref="string"/> description.
        /// </returns>
        /// <exception cref="ArgumentNullException">
        /// Value of the enum was not valid.
        /// </exception>
        public static string GetDescription(Enum value)
        {
            var description = value.ToString();
            if (string.IsNullOrWhiteSpace(description))
            {
                throw new ArgumentNullException(nameof(value));
            }

            var fieldInfo = value.GetType().GetField(description);
            if (Attribute.GetCustomAttribute(fieldInfo, typeof(DescriptionAttribute)) is DescriptionAttribute attribute)
            {
                description = attribute.Description;
            }

            return description;
        }
    }
}