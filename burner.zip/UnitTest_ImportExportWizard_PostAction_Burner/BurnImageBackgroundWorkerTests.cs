﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BurnImageBackgroundWorkerTests.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace UnitTest_ImportExportWizard_PostAction_Burner
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Runtime.InteropServices.ComTypes;

    using FluentAssertions;

    using ImportExportWizard_PostAction_Burner;
    using ImportExportWizard_PostAction_Burner.Interop;
    using ImportExportWizard_PostAction_Burner.MediaItem;
    using ImportExportWizard_PostAction_Burner.Worker;
    using ImportExportWizard_PostAction_Burner.Worker.Configuration;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Moq;

    /// <summary>
    /// Burn image background worker tests.
    /// </summary>
    [TestClass]
    public class BurnImageBackgroundWorkerTests
    {
        /// <summary>
        /// Write speed descriptor.
        /// </summary>
        private Mock<IWriteSpeedDescriptor> writeSpeedDescriptor;

        /// <summary>
        /// Disc recorder.
        /// </summary>
        private Mock<MsftDiscRecorder2> discRecorder;

        /// <summary>
        /// Media burner.
        /// </summary>
        private Mock<IMediaBurner> mediaBurner;

        /// <summary>
        /// Existing configuration data.
        /// </summary>
        private BurnImageConfigurationData existingConfiguration;

        /// <summary>
        /// Gets or sets the existing test source ISO created in the temporary directory.
        /// </summary>
        public static string TestExistingIsoFile { get; set; }

        /// <summary>
        /// Gets or sets the invalid test source ISO which doesn't exist.
        /// </summary>
        public static string TestMissingIsoFile { get; set; }

        /// <summary>
        /// Initialise the test class.
        /// </summary>
        /// <param name="context">
        /// The context.
        /// </param>
        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            TestExistingIsoFile = Path.GetTempFileName();
            File.WriteAllText(TestExistingIsoFile, "Hello, world!");
        }

        /// <summary>
        /// Cleanup the test class.
        /// </summary>
        [ClassCleanup]
        public static void ClassCleanup()
        {
            if (File.Exists(TestExistingIsoFile))
            {
                File.Delete(TestExistingIsoFile);
            }
        }

        /// <summary>
        /// Initialise the test method.
        /// </summary>
        [TestInitialize]
        public void TestInit()
        {
            this.writeSpeedDescriptor = new Mock<IWriteSpeedDescriptor>(MockBehavior.Strict);
            this.writeSpeedDescriptor.Setup(x => x.WriteSpeed).Returns(2550);
            this.discRecorder = new Mock<MsftDiscRecorder2>(MockBehavior.Strict);
            this.discRecorder.Setup(x => x.ActiveDiscRecorder).Returns("active disc recorder string");
            this.mediaBurner = new Mock<IMediaBurner>(MockBehavior.Strict);
            this.mediaBurner.Setup(x => x.RecordersInfo)
                .Returns(new[] { new KeyValuePair<MsftDiscRecorder2, string>(this.discRecorder.Object, @"F:\") });
            this.mediaBurner.Setup(x => x.GetSpeedDescriptors(this.discRecorder.Object))
                .Returns(
                    new[]
                    {
                        new KeyValuePair<IWriteSpeedDescriptor, string>(this.writeSpeedDescriptor.Object, "2550")
                    });
            this.existingConfiguration = new BurnImageConfigurationData
            {
                Eject = false,
                ForceClose = true,
                ImageFile = TestExistingIsoFile,
                Recorder = @"F:\"
            };
        }

        /// <summary>
        /// Test to ensure that when no error is returned from the media burner the worker
        /// succeeds.
        /// </summary>
        [TestMethod]
        public void EnsureBurnImageSucceedsWhenNoErrorTest()
        {
            // arrange
            this.mediaBurner.Setup(
                    x => x.WriteStream(It.IsAny<IStream>(), "active disc recorder string", "IMAPI2", true, 2550, false))
                .Returns(0);

            // act
            var sut = new BurnImageBackgroundWorker(this.mediaBurner.Object, this.existingConfiguration);
            sut.RunAsync().WhileBusy(null).Wait(TimeSpan.FromSeconds(2));

            // assert
            sut.Result.Should().Be(0);
            sut.Error.Should().Be(null);
        }

        /// <summary>
        /// Test to ensure that when the media burner returns an exit code the worker fails with
        /// the same exit code.
        /// </summary>
        [TestMethod]
        public void EnsureBurnImageFailsWhenMediaBurnerReturnsErrorTest()
        {
            // arrange
            this.mediaBurner.Setup(
                    x => x.WriteStream(It.IsAny<IStream>(), "active disc recorder string", "IMAPI2", true, 2550, false))
                .Returns(-999);

            // act
            var sut = new BurnImageBackgroundWorker(this.mediaBurner.Object, this.existingConfiguration);
            sut.RunAsync().WhileBusy(null).Wait(TimeSpan.FromSeconds(2));

            // assert
            sut.Result.Should().Be(-999);
            sut.Error.Should().Be(null);
        }

        /// <summary>
        /// Test to ensure that when the media burner throws an <see cref="Exception"/> the worker
        /// fails with the same hresult.
        /// </summary>
        [TestMethod]
        public void EnsureBurnImageFailsWhenMediaBurnerThrowsExceptionTest()
        {
            // arrange
            var exception = new Exception("Media burner error");
            this.mediaBurner.Setup(
                    x => x.WriteStream(It.IsAny<IStream>(), "active disc recorder string", "IMAPI2", true, 2550, false))
                .Throws(exception);

            // act
            var sut = new BurnImageBackgroundWorker(this.mediaBurner.Object, this.existingConfiguration);
            sut.RunAsync().WhileBusy(null).Wait(TimeSpan.FromSeconds(2));

            // assert
            sut.Result.Should().Be(exception.HResult);
            sut.Error.Should().Be(exception);
        }

        /// <summary>
        /// Test to ensure that when the media is missing the media burner throws an exception and
        /// the worker fails.
        /// </summary>
        [TestMethod]
        public void EnsureBurnImageFailsWhenMediaIsMissingTest()
        {
            // arrange
            var missingConfiguration = new BurnImageConfigurationData
            {
                Eject = false,
                ForceClose = true,
                ImageFile = TestMissingIsoFile,
                Recorder = @"F:\"
            };

            this.mediaBurner.Setup(
                    x => x.WriteStream(It.IsAny<IStream>(), "active disc recorder string", "IMAPI2", true, 2550, false))
                .Returns(0);

            // act
            var sut = new BurnImageBackgroundWorker(this.mediaBurner.Object, missingConfiguration);
            sut.RunAsync().WhileBusy(null).Wait(TimeSpan.FromSeconds(2));

            // assert
            sut.Result.Should().NotBe(0);
            sut.Error.Should().NotBeNull();
        }
    }
}