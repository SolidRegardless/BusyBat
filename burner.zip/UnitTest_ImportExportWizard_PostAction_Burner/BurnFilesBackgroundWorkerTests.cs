﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BurnFilesBackgroundWorkerTests.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace UnitTest_ImportExportWizard_PostAction_Burner
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    using FluentAssertions;

    using ImportExportWizard_PostAction_Burner;
    using ImportExportWizard_PostAction_Burner.Interop;
    using ImportExportWizard_PostAction_Burner.MediaItem;
    using ImportExportWizard_PostAction_Burner.Worker;
    using ImportExportWizard_PostAction_Burner.Worker.Configuration;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Moq;

    /// <summary>
    /// Burn files background worker tests.
    /// </summary>
    [TestClass]
    public class BurnFilesBackgroundWorkerTests
    {
        /// <summary>
        /// Existing media items.
        /// </summary>
        private IMediaItem[] existingMediaItems;

        /// <summary>
        /// Missing media items.
        /// </summary>
        private IMediaItem[] missingMediaItems;

        /// <summary>
        /// Write speed descriptor.
        /// </summary>
        private Mock<IWriteSpeedDescriptor> writeSpeedDescriptor;

        /// <summary>
        /// Disc recorder.
        /// </summary>
        private Mock<MsftDiscRecorder2> discRecorder;

        /// <summary>
        /// Media burner.
        /// </summary>
        private Mock<IMediaBurner> mediaBurner;

        /// <summary>
        /// Configuration data with existing media items.
        /// </summary>
        private BurnFilesConfigurationData existsConfiguration;

        /// <summary>
        /// Configuration data with missing media items.
        /// </summary>
        private BurnFilesConfigurationData missingConfiguration;

        /// <summary>
        /// Gets or sets the existing test source file created in the temporary directory.
        /// </summary>
        public static string TestExistingSourceFile { get; set; }

        /// <summary>
        /// Gets or sets the invalid test source file which doesn't exist.
        /// </summary>
        public static string TestMissingSourceFile { get; set; }

        /// <summary>
        /// Initialise the test class.
        /// </summary>
        /// <param name="context">
        /// The context.
        /// </param>
        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            TestExistingSourceFile = Path.GetTempFileName();
            File.WriteAllText(TestExistingSourceFile, "Hello, world!");
        }

        /// <summary>
        /// Cleanup the test class.
        /// </summary>
        [ClassCleanup]
        public static void ClassCleanup()
        {
            if (File.Exists(TestExistingSourceFile))
            {
                File.Delete(TestExistingSourceFile);
            }
        }

        /// <summary>
        /// Initialise the test method.
        /// </summary>
        [TestInitialize]
        public void TestInit()
        {
            this.existingMediaItems = new IMediaItem[] { new FileItem(TestExistingSourceFile) };
            this.writeSpeedDescriptor = new Mock<IWriteSpeedDescriptor>(MockBehavior.Strict);
            this.writeSpeedDescriptor.Setup(x => x.WriteSpeed).Returns(2550);
            this.discRecorder = new Mock<MsftDiscRecorder2>(MockBehavior.Strict);
            this.discRecorder.Setup(x => x.ActiveDiscRecorder).Returns("active disc recorder string");
            this.mediaBurner = new Mock<IMediaBurner>(MockBehavior.Strict);
            this.mediaBurner.Setup(x => x.RecordersInfo)
                .Returns(new[] { new KeyValuePair<MsftDiscRecorder2, string>(this.discRecorder.Object, @"F:\") });
            this.mediaBurner.Setup(x => x.GetSpeedDescriptors(this.discRecorder.Object))
                .Returns(
                    new[]
                    {
                        new KeyValuePair<IWriteSpeedDescriptor, string>(this.writeSpeedDescriptor.Object, "2550")
                    });
            this.existsConfiguration = new BurnFilesConfigurationData
            {
                FileSystems = FsiFileSystems.FsiFileSystemISO9660 | FsiFileSystems.FsiFileSystemJoliet,
                VolumeLabel = "volume label",
                Eject = false,
                ForceClose = true,
                MediaItems = this.existingMediaItems,
                Recorder = @"F:\"
            };
        }

        /// <summary>
        /// Test to ensure that when no error is returned from the media burner the worker
        /// succeeds.
        /// </summary>
        [TestMethod]
        public void EnsureBurnFilesSucceedsWhenNoErrorTest()
        {
            // arrange
            this.mediaBurner.Setup(
                    x => x.WriteContent(
                        "IMAPI2",
                        "active disc recorder string",
                        "volume label",
                        this.existingMediaItems,
                        true,
                        2550,
                        false,
                        FsiFileSystems.FsiFileSystemISO9660 | FsiFileSystems.FsiFileSystemJoliet))
                .Returns(0);

            // act
            var sut = new BurnFilesBackgroundWorker(this.mediaBurner.Object, this.existsConfiguration);
            sut.RunAsync().WhileBusy(null).Wait(TimeSpan.FromSeconds(2));

            // assert
            sut.Result.Should().Be(0);
            sut.Error.Should().Be(null);
        }

        /// <summary>
        /// Test to ensure that when the media burner returns an exit code the worker fails with
        /// the same exit code.
        /// </summary>
        [TestMethod]
        public void EnsureBurnFilesFailsWhenMediaBurnerReturnsErrorTest()
        {
            // arrange
            this.mediaBurner.Setup(
                    x => x.WriteContent(
                        "IMAPI2",
                        "active disc recorder string",
                        "volume label",
                        this.existingMediaItems,
                        true,
                        2550,
                        false,
                        FsiFileSystems.FsiFileSystemISO9660 | FsiFileSystems.FsiFileSystemJoliet))
                .Returns(-999);

            // act
            var sut = new BurnFilesBackgroundWorker(this.mediaBurner.Object, this.existsConfiguration);
            sut.RunAsync().WhileBusy(null).Wait(TimeSpan.FromSeconds(2));

            // assert
            sut.Result.Should().Be(-999);
            sut.Error.Should().Be(null);
        }

        /// <summary>
        /// Test to ensure that when the media burner throws an <see cref="Exception"/> the worker
        /// fails with the same hresult.
        /// </summary>
        [TestMethod]
        public void EnsureBurnFilesFailsWhenMediaBurnerThrowsExceptionTest()
        {
            // arrange
            var exception = new Exception("Media burner error");
            this.mediaBurner.Setup(
                    x => x.WriteContent(
                        "IMAPI2",
                        "active disc recorder string",
                        "volume label",
                        this.existingMediaItems,
                        true,
                        2550,
                        false,
                        FsiFileSystems.FsiFileSystemISO9660 | FsiFileSystems.FsiFileSystemJoliet))
                .Throws(exception);

            // act
            var sut = new BurnFilesBackgroundWorker(this.mediaBurner.Object, this.existsConfiguration);
            sut.RunAsync().WhileBusy(null).Wait(TimeSpan.FromSeconds(2));

            // assert
            sut.Result.Should().Be(exception.HResult);
            sut.Error.Should().Be(exception);
        }

        /// <summary>
        /// Test to ensure that when the media is missing the media burner throws an exception and
        /// the worker fails.
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(FileNotFoundException))]
        public void EnsureBurnFilesFailsWhenMediaIsMissingTest()
        {
            // arrange
            this.missingMediaItems = new IMediaItem[] { new FileItem(TestMissingSourceFile) };
            this.missingConfiguration = new BurnFilesConfigurationData
            {
                FileSystems = FsiFileSystems.FsiFileSystemISO9660 | FsiFileSystems.FsiFileSystemJoliet,
                VolumeLabel = "volume label",
                Eject = false,
                ForceClose = true,
                MediaItems = this.missingMediaItems,
                Recorder = @"F:\"
            };

            this.mediaBurner.Setup(
                    x => x.WriteContent(
                        "IMAPI2",
                        "active disc recorder string",
                        "volume label",
                        this.missingMediaItems,
                        true,
                        2550,
                        false,
                        FsiFileSystems.FsiFileSystemISO9660 | FsiFileSystems.FsiFileSystemJoliet))
                .Returns(0);

            // act
            var sut = new BurnFilesBackgroundWorker(this.mediaBurner.Object, this.missingConfiguration);
            sut.RunAsync().WhileBusy(null).Wait(TimeSpan.FromSeconds(2));

            // assert
        }
    }
}