﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Program.cs" company="BAE Systems Integrated System Technologies Limited">
//   All rights are reserved. Reproduction or transmission in whole or in part, in any form or by any means,
//   electronic, mechanical or otherwise, is prohibited without the prior written consent of the copyright owner.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace ImportExportWizard_PostAction_BurnerTestHarness
{
    using System;

    using ImportExportWizard_PostAction_Burner.Interop;
    using ImportExportWizard_PostAction_Burner.MediaItem;
    using ImportExportWizard_PostAction_Burner.Worker;
    using ImportExportWizard_PostAction_Burner.Worker.Configuration;

    /// <summary>
    /// The main program entry class.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// The main program entry point.
        /// </summary>
        /// <param name="parameters">
        /// The application command line parameters.
        /// </param>
        public static void Main(string[] parameters)
        {
            // NOTE: this test depends on the following items existing so adjust where appropriate
            // for your test environment:

            // 1. Writeable recorder as drive letter E:\
            // 2. Test text file at d:\temp\test.txt
            // 3. Test ISO at D:\Temp\test.iso

            // format disc
            new FormatDiscBackgroundWorker(
                    new FormatDiscConfigurationData { Recorder = @"E:\", Quick = true, Eject = false }).RunAsync()
                .WhileBusy(
                    (sender, args) =>
                    {
                        Console.WriteLine($"[{args.ProgressPercentage.ToString().PadLeft(3)}]: {args.UserState}");
                    })
                .Wait();

            // burn content
            new BurnFilesBackgroundWorker(
                    new BurnFilesConfigurationData
                    {
                        Recorder = @"E:\",
                        ForceClose = true,
                        Eject = false,
                        VolumeLabel = "new label",
                        MediaItems =
                            new IMediaItem[]
                            {
                                new FileItem(
                                    @"D:\Temp\Test.txt"),
                            },
                        FileSystems = FsiFileSystems.FsiFileSystemUDF
                    }).RunAsync()
                .WhileBusy(
                    (sender, args) =>
                    {
                        Console.WriteLine($"[{args.ProgressPercentage.ToString().PadLeft(3)}]: {args.UserState}");
                    })
                .Wait();

            // format disc
            new FormatDiscBackgroundWorker(
                    new FormatDiscConfigurationData { Recorder = @"E:\", Quick = true, Eject = false }).RunAsync()
                .WhileBusy(
                    (sender, args) =>
                    {
                        Console.WriteLine($"[{args.ProgressPercentage.ToString().PadLeft(3)}]: {args.UserState}");
                    })
                .Wait();

            // burn ISO
            new BurnImageBackgroundWorker(
                    new BurnImageConfigurationData
                    {
                        Recorder = @"E:\",
                        ImageFile = @"D:\Temp\Test.iso",
                        ForceClose = true,
                        Eject = false
                    }).RunAsync()
                .WhileBusy(
                    (sender, args) =>
                    {
                        Console.WriteLine($"[{args.ProgressPercentage.ToString().PadLeft(3)}]: {args.UserState}");
                    })
                .Wait();
        }
    }
}